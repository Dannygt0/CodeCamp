--CREACION DEL LAS DISTINTAS TABLAS 
Create table estados(
idestados int Primary Key,
nombre varchar(45)NOT NULL
);
Create table rol (
idRol int Primary Key,
nombre varchar(45) NOT NULL
);
Create table usuarios (
idUsuarios int Primary Key,
rol_idrol int,
estados_idestados int,
correo_electronico varchar(256) NOT NULL,
nombre_completo varchar (100)Not Null,
password varchar(45) Not null,
telefono varchar(45)Not null,
fecha_nacimiento date Not null,
fecha_creacion datetime Not null
Foreign Key (rol_idrol) references rol(idrol), 
Foreign Key (estados_idestados) references estados(idestados)
);

Create table CategoriaProductos(
idCategoriaProductos int Primary Key,
usuarios_idUsuarios int,
nombre varchar(45) Not Null,
estados_idEstados int,
fecha_creacion DateTime
Foreign Key (usuarios_idUsuarios) references Usuarios(idUsuarios),
Foreign Key (estados_idEstados) references Estados(idEstados)
);
CREATE TABLE Productos (
idProductos INT PRIMARY KEY,
CategoriaProductos_idCategoriaProductos INT,
usuarios_idUsuarios INT,
nombre VARCHAR(45) NOT NULL,
marca VARCHAR(45) NOT NULL,
codigo VARCHAR(45) NOT NULL,
stock FLOAT,
estados_idestados INT,
precio FLOAT,
fecha_creacion DATETIME,
foto BINARY,
FOREIGN KEY (CategoriaProductos_idCategoriaProductos) references CategoriaProductos(idCategoriaProductos),
FOREIGN KEY (Usuarios_idUsuarios) REFERENCES Usuarios(idUsuarios),
FOREIGN KEY (estados_idEstados) REFERENCES Estados(idEstados)
);
CREATE TABLE Orden (
idOrden INT PRIMARY KEY,
usuarios_idUsuarios INT,
estados_idEstados INT,
fecha_creacion DATETIME NOT NULL,
nombre_completo VARCHAR(45) NOT NULL,
direccion VARCHAR(545)NOT NULL,
telefono VARCHAR(45)NOT NULL,
correo_electronico VARCHAR(256)NOT NULL,
fecha_entrega DATE NOT NULL,
total_orden FLOAT NOT NULL,
Foreign key (usuarios_idUsuarios) references Usuarios(idUsuarios),
FOREIGN KEY (estados_idEstados) references Estados(idEstados)
);
CREATE TABLE OrdenDetalles (
idOrdenDetalles INT PRIMARY KEY,
Orden_IdOrden INT,
Productos_IdProductos INT,
Cantidad INT,
Precio FLOAT,
Subtotal FLOAT,
FOREIGN KEY(Orden_IdOrden) references Orden(IdOrden),
FOREIGN KEY(Productos_IdProductos) REFERENCES Productos(IdProductos)
);
--PROCEDURES Tabla IN ESTADO--
--Con la opcion de ver la tabla al final--
GO
------------------------PROCEDURES/ACTUALIZAR-----------------------------------------------
--Procedure/Actualizar Estado
CREATE PROCEDURE InsertarEstado
    @idEstados INT,
    @nombre VARCHAR(45)
AS
BEGIN
    INSERT INTO estados (idEstados, nombre)
    VALUES (@idEstados, @nombre)
END
GO
CREATE PROCEDURE ActualizarEstado
    @idEstados INT,
    @nombre VARCHAR(45)
AS
BEGIN
    UPDATE estados
    SET nombre = @nombre
    WHERE idEstados = @idEstados;
END
exec InsertarEstado @idEstados=2, @nombre='Activo';
exec ActualizarEstado @idEstados=2, @nombre='Activo';
Select * from estados;
GO
--Procedures/Actualizar RoL--
--Con la opcion de ver la tabla al final--
--Ingrese Drop if Exist ya que habia lo habia hecho malo y lo rehice-
DROP PROCEDURE if EXISTS InsertarRol;
GO
CREATE PROCEDURE InsertarRoL
	@idRol INT,
	@nombre VARCHAR(45)
AS
BEGIN
	INSERT INTO rol (idRol, nombre)
	VALUES (@idRol,@nombre)
END
GO
CREATE PROCEDURE ActualizarRol
    @idRol INT,
    @nombre VARCHAR(45)
AS
BEGIN
    UPDATE rol
    SET nombre = @nombre
    WHERE idRol = @idRol;
END
Exec InsertarROL @idRol=9,@nombre='Jorge';
Exec ActualizarRol @idRol=9,@nombre='Jorge';
Select * from rol;
GO
--Procedures/Actualizar Usuarios
CREATE PROCEDURE InsertarUsuarios
	@idUsuarios INT,
	@rol_idRol INT,
	@estados_idestados INT,
	@correo_electronico VARCHAR(256),
	@nombre_completo VARCHAR(45),
	@password VARCHAR(45),
	@telefono VARCHAR(45),
	@fecha_nacimiento DATE,
	@fecha_creacion DATETIME
AS
BEGIN
	INSERT INTO usuarios(idUsuarios,rol_idrol,estados_idestados,correo_electronico,nombre_completo,password,telefono,fecha_nacimiento,fecha_creacion)
	Values (@idUsuarios,@rol_idRol,@estados_idestados,@correo_electronico,@nombre_completo,@password,@telefono,@fecha_nacimiento,@fecha_creacion)
END
GO
CREATE PROCEDURE ActualizarUsuario
    @idUsuarios INT,
    @rol_idRol INT,
    @estados_idestados INT,
    @correo_electronico VARCHAR(256),
    @nombre_completo VARCHAR(100),
    @password VARCHAR(45),
    @telefono VARCHAR(45),
    @fecha_nacimiento DATE
AS
BEGIN
    UPDATE usuarios
    SET rol_idrol = @rol_idRol,
        estados_idestados = @estados_idestados,
        correo_electronico = @correo_electronico,
        nombre_completo = @nombre_completo,
        password = @password,
        telefono = @telefono,
        fecha_nacimiento = @fecha_nacimiento
    WHERE idUsuarios = @idUsuarios;
END
EXEC InsertarUsuarios 
@idUsuarios=2,
@rol_idrol=9,
@estados_idestados=2,
@correo_electronico='daniel.munoz@telusinternational.com',
@nombre_completo='Marilyn Zepeda',
@password='Hola123',
@telefono=45660368,
@fecha_nacimiento='1998-08-08',
@fecha_creacion='2024-08-01';
EXEC AcActualizarUsuario
@idUsuarios=2,
@rol_idrol=9,
@estados_idestados=2,
@correo_electronico='daniel.munoz@telusinternational.com',
@nombre_completo='Marilyn Zepeda',
@password='Hola123',
@telefono=45660368,
@fecha_nacimiento='1998-08-08',
@fecha_creacion='2024-08-01';

Select * from usuarios;
GO
--Procedures/Actualizar CategoriaProducto
CREATE PROCEDURE InsertarCategoriaProducto
	@idCategoriaProductos INT,
	@usuarios_idUsuarios INT,
	@nombre VARCHAR(45),
	@estados_idEstados INT,
	@fecha_creacion DATETIME
AS
BEGIN 
	INSERT INTO CategoriaProductos (idCategoriaProductos,usuarios_idUsuarios,nombre,estados_idEstados,fecha_creacion)
	VALUES (@idCategoriaProductos, @usuarios_idUsuarios, @nombre, @estados_idEstados, @fecha_creacion)
END
GO
CREATE PROCEDURE ActualizarCategoriaProducto
    @idCategoriaProductos INT,
    @usuarios_idUsuarios INT,
    @nombre VARCHAR(45),
    @estados_idEstados INT
AS
BEGIN
    UPDATE CategoriaProductos
    SET usuarios_idUsuarios = @usuarios_idUsuarios,
        nombre = @nombre,
        estados_idEstados = @estados_idEstados
    WHERE idCategoriaProductos = @idCategoriaProductos;
END
GO
EXEC InsertarCategoriaProducto @idCategoriaProductos=1 ,@usuarios_idUsuarios= 2,
@nombre ='Zappos',@estados_idEstados=2,@fecha_creacion='2024-06-07';
Select * from CategoriaProductos;
GO
--Procedures/Actualizar Producto
DROP PROCEDURE if EXISTS InsertarProducto;
GO
CREATE PROCEDURE InsertarProducto
    @idProductos INT,
    @CategoriaProductos_idCategoriaProductos INT,
    @usuarios_idUsuarios INT,
    @nombre VARCHAR(45),
    @marca VARCHAR(45),
    @codigo VARCHAR(45),
    @stock FLOAT,
    @estados_idestados INT,
    @precio FLOAT,
    @fecha_creacion DATETIME,
    @foto BINARY
AS
BEGIN
    INSERT INTO Productos (idProductos, CategoriaProductos_idCategoriaProductos, usuarios_idUsuarios, nombre, marca, codigo, stock, estados_idestados, precio, fecha_creacion, foto)
    VALUES (@idProductos, @CategoriaProductos_idCategoriaProductos, @usuarios_idUsuarios, @nombre, @marca, @codigo, @stock, @estados_idestados, @precio, @fecha_creacion, @foto)
END
GO
CREATE PROCEDURE ActualizarProducto
    @idProductos INT,
    @CategoriaProductos_idCategoriaProductos INT,
    @usuarios_idUsuarios INT,
    @nombre VARCHAR(45),
    @marca VARCHAR(45),
    @codigo VARCHAR(45),
    @stock FLOAT,
    @estados_idestados INT,
    @precio FLOAT
AS
BEGIN
    UPDATE Productos
    SET CategoriaProductos_idCategoriaProductos = @CategoriaProductos_idCategoriaProductos,
        usuarios_idUsuarios = @usuarios_idUsuarios,
        nombre = @nombre,
        marca = @marca,
        codigo = @codigo,
        stock = @stock,
        estados_idestados = @estados_idestados,
        precio = @precio
    WHERE idProductos = @idProductos;
END
GO
EXEC InsertarProducto 
@idProductos =1, 
@CategoriaProductos_idCategoriaProductos=1,
@usuarios_idUsuarios=2,
@nombre ='Frijoles',
@marca = 'B&B',
@codigo = '3413442',
@stock = '123',
@estados_idestados ='1',
@precio= '12.30',
@fecha_creacion = '2023-12-23',
@foto = NULL;

Select * from Productos         ;
GO
--Procedures/Actualizar Orden
CREATE PROCEDURE InsertarOrden
    @idOrden INT,
    @usuarios_idUsuarios INT,
    @estados_idEstados INT,
    @fecha_creacion DATETIME,
    @nombre_completo VARCHAR(45),
    @direccion VARCHAR(545),
    @telefono VARCHAR(45),
    @correo_electronico VARCHAR(256),
    @fecha_entrega DATE,
    @total_orden FLOAT
AS
BEGIN
    INSERT INTO Orden (idOrden, usuarios_idUsuarios, estados_idEstados, fecha_creacion, nombre_completo, direccion, telefono, correo_electronico, fecha_entrega, total_orden)
    VALUES (@idOrden, @usuarios_idUsuarios, @estados_idEstados, @fecha_creacion, @nombre_completo, @direccion, @telefono, @correo_electronico, @fecha_entrega, @total_orden)
END
GO
CREATE PROCEDURE ActualizarOrden
    @idOrden INT,
    @usuarios_idUsuarios INT,
    @estados_idEstados INT,
    @nombre_completo VARCHAR(45),
    @direccion VARCHAR(545),
    @telefono VARCHAR(45),
    @correo_electronico VARCHAR(256),
    @fecha_entrega DATE,
    @total_orden FLOAT
AS
BEGIN
    UPDATE Orden
    SET usuarios_idUsuarios = @usuarios_idUsuarios,
        estados_idEstados = @estados_idEstados,
        nombre_completo = @nombre_completo,
        direccion = @direccion,
        telefono = @telefono,
        correo_electronico = @correo_electronico,
        fecha_entrega = @fecha_entrega,
        total_orden = @total_orden
    WHERE idOrden = @idOrden;
END
GO
EXEC InsertarOrden
@idOrden =1, 
@usuarios_idUsuarios=2,
@estados_idestados ='1',
@fecha_creacion ='2023-09-23',
@nombre_completo ='AMX',
@direccion= 'Santa Catarina Pinula',
@telefono= 45660348,
@correo_electronico ='dmuoz1997@gmail.com',
@fecha_entrega = '2023-12-23',
@total_orden = 12.56;

Select * from Productos         ;
GO

--PROCEDURE ORDEN DETALLES
CREATE PROCEDURE InsertarOrdenDetalles
    @idOrdenDetalles INT,
    @Orden_IdOrden INT,
    @Productos_IdProductos INT,
    @Cantidad INT,
    @Precio FLOAT,
    @Subtotal FLOAT
AS
BEGIN
    INSERT INTO OrdenDetalles (idOrdenDetalles, Orden_IdOrden, Productos_IdProductos, Cantidad, Precio, Subtotal)
    VALUES (@idOrdenDetalles, @Orden_IdOrden, @Productos_IdProductos, @Cantidad, @Precio, @Subtotal)
END
GO
CREATE PROCEDURE ActualizarOrdenDetalles
    @idOrdenDetalles INT,
    @Orden_IdOrden INT,
    @Productos_IdProductos INT,
    @Cantidad INT,
    @Precio FLOAT,
    @Subtotal FLOAT
AS
BEGIN
    UPDATE OrdenDetalles
    SET Orden_IdOrden = @Orden_IdOrden,
        Productos_IdProductos = @Productos_IdProductos,
        Cantidad = @Cantidad,
        Precio = @Precio,
        Subtotal = @Subtotal
    WHERE idOrdenDetalles = @idOrdenDetalles;
END
GO
EXEC InsertarOrdenDetalles
@idOrdenDetalles =1,
@Orden_IdOrden=1,
@Productos_IdProductos= 1,
@Cantidad =2,
@Precio = 122.56,
@Subtotal = 23.67;

Select * from Productos         ;
GO


------------CONSULTAS---------------------
CREATE VIEW VistaProductosActivos AS
SELECT *
FROM Productos
WHERE estados_idestados = 1
AND stock > 0;
GO

--Segunda Consulta
CREATE VIEW VistaTotalQuetzalesAgosto2024 AS
SELECT SUM(total_orden) AS TotalQuetzalesAgosto2024
FROM Orden
WHERE fecha_creacion >= '2024-08-01'
  AND fecha_creacion < '2024-09-01';
GO

--Tercera Consulta
CREATE VIEW VistaTop10UsuariosConsumo AS
SELECT TOP 10
    u.idUsuarios,
    u.nombre_completo,
    SUM(o.total_orden) AS TotalConsumo
FROM Orden o
JOIN usuarios u ON o.usuarios_idUsuarios = u.idUsuarios
GROUP BY u.idUsuarios, u.nombre_completo
ORDER BY TotalConsumo DESC;
GO
--Cuarta Consulta
CREATE VIEW VistaTop10ProductosVendidos AS
SELECT TOP 10
    p.idProductos,
    p.nombre AS nombre_producto,
    SUM(od.Cantidad) AS TotalCantidadVendida
FROM OrdenDetalles od
JOIN Productos p ON od.Productos_IdProductos = p.idProductos
GROUP BY p.idProductos, p.nombre
ORDER BY TotalCantidadVendida DESC;
GO
-----------------PARA ACTUALIZACION ----------------------
CREATE PROCEDURE ActualizarEstado
    @idEstados INT,
    @nombre VARCHAR(45)
AS
BEGIN
    UPDATE estados
    SET nombre = @nombre
    WHERE idEstados = @idEstados;
END
GO

Select * from CategoriaProductos;
Select * from estados;
Select * from Orden;
Select * from OrdenDetalles;
Select * from Productos;
Select * from rol;
Select * from usuarios;